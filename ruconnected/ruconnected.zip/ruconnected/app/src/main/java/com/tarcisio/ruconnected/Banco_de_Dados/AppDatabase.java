/*package com.tarcisio.ruconnected.Banco_de_Dados;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.tarcisio.ruconnected.DAO.ComidaDAO;
import com.tarcisio.ruconnected.DAO.FeedBackDAO;
import com.tarcisio.ruconnected.DAO.UsuarioDAO;
import com.tarcisio.ruconnected.Model.Comida;
import com.tarcisio.ruconnected.Model.FeedBack;
import com.tarcisio.ruconnected.Model.Usuario;

@Database(entities = {Usuario.class, Comida.class, FeedBack.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {

    public abstract UsuarioDAO usuarioDAO();

    public abstract ComidaDAO comidaDAO();

    public abstract FeedBackDAO feedBackDAO();

}*/
